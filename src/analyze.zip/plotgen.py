import matplotlib.pyplot as plt
from analyze import load_v2, SECONDARY_TOOLS

def get_data(data, durs, tool):
    x = []
    for b, d in data.items():
        if d[tool] in ['sat', 'unsat']:
            tm = durs[b][tool]
            if tool.startswith('myapp'):
                tm += durs[b]['myapp']
            x.append(tm)
    x.sort()
    y = list(range(1, len(x) + 1))
    return x, y


def main():
    data = {}
    durs = {}
    load_v2('results.txt', ['myapp', 'z3_sg', 'q3b_sg', 'cvc5_sg', 'bitw_sg'] + [f'myapp_sg_20+{t}_40' for t in SECONDARY_TOOLS], data, durs)

    s = get_data(data, durs, 'myapp_sg_20+bitw_40')
    u = get_data(data, durs, 'myapp_sg_20+cvc5_40')
    t = get_data(data, durs, 'q3b_sg')

    plt.figure(figsize=(8, 5))
    for t in ['z3_sg', 'q3b_sg', 'cvc5_sg', 'bitw_sg'] + [f'myapp_sg_20+{t}_40' for t in SECONDARY_TOOLS]:
        plt.step(*get_data(data, durs, t), where='post', label=t)
    plt.xlabel('Time (ms)')
    plt.ylabel('Benchmarks solved')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('plt.pdf')

if __name__ == '__main__':
    main()